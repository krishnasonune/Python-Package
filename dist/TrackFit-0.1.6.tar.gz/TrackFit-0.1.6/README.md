
# TrackFit

TrackFit helps you to keep track of your calories to reach your goal faster in short time

## Installation

To install this package

```bash
  pip install TrackFit
```


## Documentation

from Trackcalories import musclegain 

from Trackcalories import maintenance

from Trackcalories import bodyrecomposition

from Trackcalories import fatloss


( Pass weight (in kgs) and height (in cms) to get accurate result )

mg =  musclegain.muscle_gain_calories(weight=78, height=178, gender= 'male', age=21)
print(mg)

mt_cal =  maintenance.maintenance_calories(weight=78, height=178, gender= 'male', age=21)
print(mt_cal)

recomp = bodyrecomposition.bodyRecomposition_calories(weight=78, height=178, gender= 'male', age=21)
print(recomp)

floss = fatloss.fatloss_calories(weight=78, height=178, gender= 'male', age=21)
print(floss)



## Authors

- [@krishna sonune](https://www.github.com/krishnasonune)

