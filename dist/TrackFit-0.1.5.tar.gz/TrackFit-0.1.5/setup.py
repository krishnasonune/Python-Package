from setuptools import setup, find_packages

VERSION = '0.1.5'
DESCRIPTION = 'My first Python package'



setup(

    name="TrackFit",
    version=VERSION,
    author="krishna sonune",
    author_email="krishnasonune87@gmail.com",
    description=DESCRIPTION,
    installation="pip install TrackFit",
    usage="from Trackcalories import musclegain"
          
          "from Trackcalories import maintenance"
          "from Trackcalories import bodyrecomposition"
          "from Trackcalories import fatloss"
          ""
          "( Pass weight (in kgs) and height (in cms) to get accurate result )"
          ""
          "mg = musclegain.muscle_gain_calories(weight=78, height=178, gender= 'male', age=21)"
          "print(mg)"
          ""
          "mt_cal = maintenance.maintenance_calories(weight=78, height=178, gender= 'male', age=21)"
          "print(mt_cal)"
          ""
          "recomp = bodyrecomposition.bodyRecomposition_calories(weight=78, height=178, gender= 'male', age=21)"
          "print(recomp)"
          ""
          "floss = fatloss.fatloss_calories(weight=78, height=178, gender= 'male', age=21)"
          "print(floss)",
    packages=find_packages(),
    install_requires=[],
    keywords=['python', 'first package'],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Education",
        "Programming Language :: Python :: 2",
        "Programming Language :: Python :: 3",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows",
    ]

)